const { createDefaultPreset } = require("ts-jest");

const tsJestTransformCfg = createDefaultPreset().transform;

/** @type {import("jest").Config} **/
module.exports = {
  testEnvironment: "node",
  transform: {
    ...tsJestTransformCfg,
  },
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/$1",
    "^expo-sqlite$": "<rootDir>/__mocks__/expo-sqlite.js"
  },
  moduleFileExtensions: ["ts", "tsx", "js", "json"],
  testMatch: ["**/ServiceTest/**/*.test.(ts|js)"]
};