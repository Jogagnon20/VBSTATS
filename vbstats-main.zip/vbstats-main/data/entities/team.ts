export interface Team {
    teamId: number;
    name: string;
    season: string;
    ownerId: number | null;
}