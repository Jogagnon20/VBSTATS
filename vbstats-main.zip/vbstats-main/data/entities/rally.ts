export interface Rally {
    rallyId: number;
    setId: number;
    startingRotationId: number;
    servingTeamId: number;
    winnerTeamId: number | null;
    rallyNo: number;
}