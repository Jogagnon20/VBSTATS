export interface Substitution {
    subId: number;
    setId: number;
    playerInId: number;
    playerOutId: number;
    positionSlot: number;
}