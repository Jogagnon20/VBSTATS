export interface Rotation {
    rotationId: number;
    setId: number;
    rotationNo: number;
    p1: number; p2: number; p3: number; p4: number; p5: number; p6: number;
}