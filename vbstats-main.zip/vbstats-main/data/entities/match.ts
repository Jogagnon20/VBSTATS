export interface Match {
    matchId: number;
    myTeamId: number;
    otherTeamId: number;
    date: string;
    location: string | null;
}