export interface Player {
    playerId: number;
    name: string;
    number: number | null;
    position: string | null;
}