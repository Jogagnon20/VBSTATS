export interface User {
    userId: number;
    name: string;
    photoUri: string | null;
}